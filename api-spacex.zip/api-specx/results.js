document.addEventListener('DOMContentLoaded', function() {
  const searchType = localStorage.getItem('searchType') || 'rockets';
  const titleElement = document.getElementById('results-title');
  const container = document.getElementById('results-container');
  const loadingElement = document.getElementById('loading');
  
  // Configura o título conforme o tipo de busca
  const titles = {
    rockets: 'Foguetes da SpaceX',
    launches: 'Lançamentos da SpaceX',
    capsules: 'Cápsulas da SpaceX'
  };
  
  titleElement.textContent = `🚀 ${titles[searchType]}`;
  
  // URLs da API
  const apiUrls = {
    rockets: 'https://api.spacexdata.com/v4/rockets',
    launches: 'https://api.spacexdata.com/v4/launches',
    capsules: 'https://api.spacexdata.com/v4/capsules'
  };
  
  // Funções para renderizar cada tipo de dado
  const renderers = {
    rockets: renderRockets,
    launches: renderLaunches,
    capsules: renderCapsules
  };
  
  // Faz a requisição para a API
  fetch(apiUrls[searchType])
    .then(response => {
      if (!response.ok) {
        throw new Error(`Erro HTTP! status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      loadingElement.style.display = 'none';
      renderers[searchType](data);
    })
    .catch(error => {
      loadingElement.innerHTML = `
        <div class="error">
          <p>Erro ao carregar os dados.</p>
          <p>${error.message}</p>
        </div>
      `;
      console.error("Erro na requisição:", error);
    });
  
  // Funções de renderização
  function renderRockets(rockets) {
    rockets.slice(0, 12).forEach(rocket => {
      const card = document.createElement('div');
      card.className = 'card';
      
      card.innerHTML = `
        <h2>${rocket.name}</h2>
        <div class="badge ${rocket.active ? 'active' : 'inactive'}">
          ${rocket.active ? 'ATIVO' : 'INATIVO'}
        </div>
        <img src="${rocket.flickr_images[0]}" alt="${rocket.name}" 
             onerror="this.src='https://via.placeholder.com/400x200?text=Imagem+Não+Disponível'">
        <p>${rocket.description}</p>
        <div class="specs">
          <p><strong>Primeiro voo:</strong> ${rocket.first_flight}</p>
          <p><strong>Altura:</strong> ${rocket.height.meters} m</p>
          <p><strong>Diâmetro:</strong> ${rocket.diameter.meters} m</p>
          <p><strong>Massa:</strong> ${rocket.mass.kg} kg</p>
          <p><strong>Custo por lançamento:</strong> $${rocket.cost_per_launch.toLocaleString()}</p>
        </div>
      `;
      
      container.appendChild(card);
    });
  }
  
  function renderLaunches(launches) {
    launches.slice(0, 12).forEach(launch => {
      const card = document.createElement('div');
      card.className = 'card';
      
      const launchDate = new Date(launch.date_utc).toLocaleDateString();
      
      card.innerHTML = `
        <h2>${launch.name}</h2>
        <div class="badge ${launch.success ? 'active' : 'inactive'}">
          ${launch.success ? 'SUCESSO' : 'FALHA'}
        </div>
        <p><strong>Data:</strong> ${launchDate}</p>
        <p>${launch.details || 'Nenhum detalhe disponível'}</p>
        <div class="specs">
          <p><strong>Número do voo:</strong> ${launch.flight_number}</p>
          <p><strong>Foguete:</strong> ${launch.rocket}</p>
          <p><strong>Local:</strong> ${launch.launchpad}</p>
        </div>
      `;
      
      container.appendChild(card);
    });
  }
  
  function renderCapsules(capsules) {
    capsules.slice(0, 12).forEach(capsule => {
      const card = document.createElement('div');
      card.className = 'card';
      
      card.innerHTML = `
        <h2>${capsule.type} - ${capsule.serial}</h2>
        <div class="badge ${capsule.status === 'active' ? 'active' : 'inactive'}">
          ${capsule.status.toUpperCase()}
        </div>
        <div class="specs">
          <p><strong>Status:</strong> ${capsule.status}</p>
          <p><strong>Lançamentos:</strong> ${capsule.launches.length}</p>
          <p><strong>Última atualização:</strong> ${capsule.last_update || 'N/A'}</p>
        </div>
      `;
      
      container.appendChild(card);
    });
  }
});