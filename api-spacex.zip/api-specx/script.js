document.addEventListener('DOMContentLoaded', function() {
  // Formulário de busca
  const searchForm = document.getElementById('search-form');
  
  if (searchForm) {
    searchForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const searchType = document.getElementById('search-type').value;
      
      if (!searchType) {
        alert('Por favor, selecione uma opção para explorar');
        return;
      }
      
      // Redireciona para a página de resultados com parâmetro na URL
      window.location.href = `results.html?type=${searchType}`;
    });
  }
  
  // Efeito de digitação no título
  const heroTitle = document.querySelector('.hero-content h1');
  if (heroTitle) {
    const originalText = heroTitle.textContent;
    heroTitle.textContent = '';
    
    let i = 0;
    const typingEffect = setInterval(() => {
      if (i < originalText.length) {
        heroTitle.textContent += originalText.charAt(i);
        i++;
      } else {
        clearInterval(typingEffect);
      }
    }, 100);
  }
  
  // Animação de scroll
  const scrollDown = document.querySelector('.scroll-down');
  if (scrollDown) {
    scrollDown.addEventListener('click', () => {
      window.scrollBy({
        top: window.innerHeight - 100,
        behavior: 'smooth'
      });
    });
  }
});